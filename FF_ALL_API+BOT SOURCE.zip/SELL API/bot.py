import telebot
from telebot import types
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import requests, subprocess
import time, os
import threading
from urllib.parse import urlparse, parse_qs
import hashlib
import urllib.request
from geopy.geocoders import Nominatim
import logging
from io import BytesIO
import re
import json
from datetime import datetime, timezone

# ========== CONFIG ==========
BOT_TOKEN = "7278850908:AAHw7jof8D-3w95oAVIa3QgPPnBcJXJCl3Q"
ADMIN_ID = 8027024808
GROUP_ID = -1002536720855
ALLOWED_GROUP_IDS = {-1002536720855, -1002869966610, 8027024808, 8027024808, -1002851559903}
VIP_USERS = {8027024808, 7544347591, 6060325391, 1725990033}
ADMINS = {8027024808, 6060325391, 7544347591, 1725990033}
like_request_tracker = {}
visit_request_tracker = {}
VISIT_USAGE_TRACKER = {}
REFERRALS = {}
REWARDED = set()
FREE_VISIT_LOG = {} 
LAST_VISIT_TIME = {}
last_like_time = {}
last_like_time_global = 0 
last_visit_time_global = 0
user_limits = {}
user_timestamps = {}
VISIT_COOLDOWNS = {}
VISIT_COOLDOWN_SECONDS = 86400
LIKE_COOLDOWNS = {} 
LIKE_COOLDOWN_SECONDS = 86400
LIKE_USAGE_TRACKER = {}
pending_timestamps = {}
user_weather_units = {} 
OFFMENU_GROUPS = set()
BANNED_GROUP_IDS = set()
NOTIFY_CHAT_IDS = [8027024808, 7544347591]
API_URL = 'https://free-fire-like.axmhere.xyz/refresh-tokens'
AUTO_INTERVAL = 7 * 3600 + 30 * 60  # 7h30m in seconds
WATERMARK = "\n  🤖 BOT BY : @AMSdeveloper"
BAR_LENGTH = 20
ANIMATION_FRAMES = [
    '░' * i + '█' + '░' * (BAR_LENGTH - i - 1)
    for i in range(BAR_LENGTH)
]
# ========== ADMIN CHECK ==========
def is_admin(user_id):
    return user_id in ADMINS
# ========== INIT BOT ==========
bot = telebot.TeleBot(BOT_TOKEN)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ========== ESCAPE FOR MarkdownV2 ==========
def escape_markdown(text):
    return re.sub(r'([_*()~`>#+=|{}.!-])', r'\\\1', str(text))

# ========== TIMESTAMP FORMATTER ==========
def format_ts(ts):
    try:
        ts = int(ts)
        if ts > 1e11:
            ts = ts // 1000
        return datetime.fromtimestamp(ts, tz=timezone.utc).strftime('%d %B %Y at %H:%M:%S')
    except Exception:
        return "N/A"

# ========== TEMP MSG FUNCTION ==========
def send_temp_message(chat_id, text, parse_mode=None):
    msg = bot.send_message(chat_id, text, parse_mode=parse_mode)
    threading.Timer(7, lambda: bot.delete_message(chat_id, msg.message_id)).start()

def send_temp_message2(chat_id, text, reply_to=None, parse_mode=None):
    msg = bot.send_message(chat_id, text, parse_mode=parse_mode, reply_to_message_id=reply_to)
    threading.Timer(7, lambda: bot.delete_message(chat_id, msg.message_id)).start()
# ========== START HANDLER ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower().split()[0] in ['!start', '/start', 'start'])
def handle_start(message):
    uid = str(message.from_user.id)
    args = message.text.split()
    if len(args) == 2 and args[1].startswith("ref_"):
        referrer_id = args[1].split("_")[1]
        if referrer_id == uid:
            bot.send_message(message.chat.id, "❌ You can't refer yourself!")
            return
        if uid in REFERRALS:
            bot.send_message(message.chat.id, "ℹ️ You already used a referral link.")
        else:
            REFERRALS[uid] = referrer_id
            send_join_verify_buttons(message, referrer_id)
            return 

    help_text = (
        "👋 Welcome to Like BD Bot !!\n\n"
        "👉 Use !help command to see all available commands.\n\n"
    )
    bot.send_message(message.chat.id, help_text) 

# ========== BUTTONS SEND FUNCTION ==========
def send_join_verify_buttons(message, referrer_id):
    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("🔗 Join Group", url=f"https://t.me/+T_rm-Sau2VkzN2Jl"),
        InlineKeyboardButton("✅ I Joined", callback_data=f"verify_{referrer_id}")
    )
    bot.send_message(
        message.chat.id,
        "👋 Welcome! You were invited by someone.\n👉 Please join the group to complete referral.",
        reply_markup=markup
    )

# ========== VERIFY JOIN BUTTON HANDLER ==========
@bot.callback_query_handler(func=lambda call: call.data.startswith("verify_"))
def handle_verification(call):
    new_user_id = str(call.from_user.id)
    referrer_id = call.data.split("_")[1]

    try:
        member = bot.get_chat_member(GROUP_ID, int(new_user_id))
        if member.status in ["member", "creator", "administrator"]:
            if new_user_id in REWARDED:
                bot.answer_callback_query(call.id, "✅ Already verified before.", show_alert=True)
                return

            # Reward the referrer
            REWARDED.add(new_user_id)

            from_user = int(referrer_id)
            LIKE_USAGE_TRACKER.setdefault(from_user, {"used": 0, "limit": 0})
            LIKE_USAGE_TRACKER[from_user]['limit'] += 1

            bot.answer_callback_query(call.id, "🎉 Referral completed! Referrer got +1 limit.", show_alert=True)
            bot.send_message(from_user, f"🎉 Someone joined using your referral! You got +1 limit.")
        else:
            bot.answer_callback_query(call.id, "❌ You haven’t joined the group yet.", show_alert=True)
            # Show buttons again
            send_join_verify_buttons(call.message, referrer_id)
    except Exception as e:
        bot.answer_callback_query(call.id, "⚠️ Error verifying group join.", show_alert=True)
        bot.send_message(ADMIN_ID, f"❌ Verify group button Error: {e}")
        send_join_verify_buttons(call.message, referrer_id)

# ========== !mylink COMMAND ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower() == "!mylink")
def mylink_handler(message):
    uid = message.from_user.id
    link = f"https://t.me/{bot.get_me().username}?start=ref_{uid}"
    bot.reply_to(message, f"🔗 Your referral link:\n{link}\n\n👉 Share this with friends. When they join the group, you'll get +1 limit!")
# ========== HELP ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower() in ['!help', 'help', '/help'])
def combined_start_help(message):
    help_text = (
        "📖 *Commands:*\n"
        "🔹 `!info <uid> <region>` — Show FF account info\n"
        "🔹 `!like <region> <uid>` — Send like to UID only BD Server\n"
        "🔹 `!visit <region> <uid>` — Send 200 Profile Visit to UID only BD Server\n"
        "🔹 `!alive <uid>` — Check Account Ban Status\n"
        "🔹 `!check <uid>` — Check Account Region + Name\n"
        "🔹 `!age` — Check Account Age + Details\n"
        "🔹 `!weather <city>` — Check Weather details of your City\n"
        "🔹 `!forecast <city> <days>` — Check weather forecast of next 1-7 days\n"
        "🔹 `!id` — Show group chat ID\n"
        "🔹 `!myid` — Show your Telegram info\n"
        f"*{WATERMARK}*"
    )
    bot.reply_to(message, help_text, parse_mode="Markdown")

@bot.message_handler(func=lambda m: m.text and m.text.startswith('!region'))
def region_ck(message):
    region_text = (
        "```🌏Available_Regions:\n"
        "1. BD — Bangladesh 🇧🇩\n"
        "2. BR — Brazil 🇧🇷\n"
        "3. CIS — Commonwealth of Independent States 🌐\n"
        "4. EU — Europe 🇪🇺\n"
        "5. ID — Indonesia 🇮🇩\n"
        "6. IND — India 🇮🇳\n"
        "7. ME — Middle East 🌍\n"
        "8. NA — North America 🌍\n"
        "9. PK — Pakistan 🇵🇰\n"
        "10. SAC — South America 🌍\n"
        "11. SG — Singapore 🇸🇬\n"
        "12. TH — Thailand 🇹🇭\n"
        "13. TW — Taiwan 🇹🇼\n"
        "14. VN — Vietnam 🇻🇳```\n"
    )
    bot.reply_to(message, region_text, parse_mode="Markdown")
# ========== ADMIN HELP ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower() in ['!adminhelp', 'adminhelp', '/adminhelp'])
def admin_start_help(message):
    if message.from_user.id not in ADMINS:
        return
    help_text = (
        "📖 *Commands:*\n"
        "🔹 `!promote <user_id>` — Promote a user as a Admin\n"
        "🔹 `!demote <user_id>` — Demote a user from Admin\n"
        "🔹 `!allow_group <group_id>` — Allow a group to use this Bot\n"
        "🔹 `!ban_group <group_id>` — Ban a group from use this Bot\n"
        "🔹 `!groups` — Show Allowed & Ban group list\n"
        "🔹 `!addlimit <count>` — Reply a user messege to add request limit\n"
        "🔹 `!addlimit all <like|visit|both> <amount>` — For add custom request limit to all users\n"
        "🔹 `!removelimit <count/all>` — Reply a user messege to remove request limit\n"
        "🔹 `!clearlimit all <like|visit|both>` — For remove custom request limit of all users\n"
        "🔹 `!stats` — Reply a user messege to see his total stats\n"
        "🔹 `!todaystats` — Reply a user messege to see his todays stats\n"
        "🔹 `!stats all` — Show All users Stats\n"
    )
    bot.reply_to(message, help_text, parse_mode="Markdown")
# ========== CHAT ID ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower() == '!id')
def group_id(message):
    bot.reply_to(message, f"🆔 *Group Chat ID:* `{message.chat.id}`", parse_mode="Markdown")

# ========== USER ID ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower() == '!myid')
def user_id(message):
    user = message.from_user
    name = escape_markdown(f"{user.first_name} {user.last_name or ''}".strip())
    username = escape_markdown(user.username) if user.username else "null"
    user_id = escape_markdown(user.id)
    text = f"🙋‍♂️ *Name:* {name}\n🌐 *Username:* `{username}`\n🆔 *User ID:* `{user_id}`"
    bot.reply_to(message, text, parse_mode="MarkdownV2") 

@bot.message_handler(func=lambda m: m.text and m.text.lower() == '!offmenu')
def disable_menu_for_group(message):
    if message.from_user.id not in ADMINS:
        return
    OFFMENU_GROUPS.add(message.chat.id)
    markup = types.ReplyKeyboardRemove()
    bot.send_message(message.chat.id, "✅ Reply menu has been disabled *completely* for this group.", reply_markup=markup, parse_mode="Markdown")
# ========== !promote & !demote ==========
@bot.message_handler(func=lambda m: m.text and m.text.startswith('!promote'))
def promote_user(message):
    if message.from_user.id != ADMIN_ID:
        return
    try:
        uid = int(message.text.split()[1])
        ADMINS.add(uid)
        bot.reply_to(message, f"✅ User `{uid}` promoted to admin.", parse_mode="Markdown")
    except:
        bot.reply_to(message, "⚠️ Usage: !promote <user_id>")

@bot.message_handler(func=lambda m: m.text and m.text.startswith('!demote'))
def demote_user(message):
    if message.from_user.id != ADMIN_ID:
        return
    try:
        uid = int(message.text.split()[1])
        if uid == ADMIN_ID:
            bot.reply_to(message, "❌ You can't demote the owner.")
        elif uid in ADMINS:
            ADMINS.remove(uid)
            bot.reply_to(message, f"🛑 User `{uid}` demoted from admin.", parse_mode="Markdown")
        else:
            bot.reply_to(message, "⚠️ That user is not an admin.")
    except:
        bot.reply_to(message, "⚠️ Usage: !demote <user_id>")

# ========== !allow_group & !ban_group ==========
@bot.message_handler(func=lambda m: m.text and m.text.startswith('!allow_group'))
def allow_group(message):
    if not is_admin(message.from_user.id):
        return
    try:
        parts = message.text.strip().split()
        if len(parts) != 2:
            raise ValueError("Invalid parts")
        gid = int(parts[1])
        #gid = int(message.text.split()[1])
        ALLOWED_GROUP_IDS.add(gid)
        bot.reply_to(message, f"✅ Group `{gid}` added to allowed list.", parse_mode="Markdown")
    except Exception as e:
        bot.reply_to(message, f"⚠️ Usage: !allow_group <group_id>")

@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!addlimit'))
def add_limit_handler(message):
    if not is_admin(message.from_user.id):
        return

    args = message.text.split()

    # --- MODE 1: !addlimit all <like|visit|both> <amount>
    if len(args) == 4 and args[1].lower() == "all" and args[3].isdigit():
        limit_type = args[2].lower()
        amount = int(args[3])
    # --- MODE 2: !addlimit all <amount>  (like+visit)
    elif len(args) == 3 and args[1].lower() == "all" and args[2].isdigit():
        limit_type = "both"
        amount = int(args[2])
    # --- MODE 3: !addlimit <amount>  (replied user)
    elif len(args) == 2 and args[1].isdigit() and message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        amount = int(args[1])
        LIKE_USAGE_TRACKER.setdefault(user_id, {"used": 0, "limit": 0})
        LIKE_USAGE_TRACKER[user_id]["limit"] += amount
        VISIT_USAGE_TRACKER.setdefault(user_id, {"used": 0, "limit": 0})
        VISIT_USAGE_TRACKER[user_id]["limit"] += amount
        return bot.reply_to(message, f"✅ Added {amount} limits to user. New total: {LIKE_USAGE_TRACKER[user_id]['limit']}")
    else:
        return bot.reply_to(message,
            "❌ Usage:\n• `!addlimit all <like|visit|both> <amount>`\n• `!addlimit all <amount>`\n• `!addlimit <amount>` (reply to user)",
            parse_mode="Markdown")

    # For MODE 1 & 2: All users
    updated = 0
    all_user_ids = set()
    all_user_ids.update(LIKE_USAGE_TRACKER.keys())
    all_user_ids.update(VISIT_USAGE_TRACKER.keys())

    for uid in all_user_ids:
        uid = int(uid)
        if limit_type in ["like", "both"]:
            LIKE_USAGE_TRACKER.setdefault(uid, {"used": 0, "limit": 0})
            LIKE_USAGE_TRACKER[uid]["limit"] += amount
        if limit_type in ["visit", "both"]:
            VISIT_USAGE_TRACKER.setdefault(uid, {"used": 0, "limit": 0})
            VISIT_USAGE_TRACKER[uid]["limit"] += amount
        updated += 1

    bot.reply_to(message, f"✅ Added {amount} `{limit_type}` limits to {updated} users.", parse_mode="Markdown")

@bot.message_handler(func=lambda m: m.reply_to_message and m.text.lower().startswith('!removelimit'))
def remove_limit(message):
    if not is_admin(message.from_user.id):
        return
    args = message.text.split()
    user_id = message.reply_to_message.from_user.id
    if len(args) != 2:
        return bot.reply_to(message, "❌ Usage: !removelimit <number|all>")

    LIKE_USAGE_TRACKER.setdefault(user_id, {"used": 0, "limit": 0})
    VISIT_USAGE_TRACKER.setdefault(user_id, {"used": 0, "limit": 0})

    if args[1].lower() == "all":
        LIKE_USAGE_TRACKER[user_id]["limit"] = 0
        VISIT_USAGE_TRACKER[user_id]["limit"] = 0
        return bot.reply_to(message, "🗑️ All limits removed for user.")
    
    if not args[1].isdigit():
        return bot.reply_to(message, "❌ Invalid input. Use number or `all`.")

    amount = int(args[1])
    LIKE_USAGE_TRACKER[user_id]["limit"] = max(0, LIKE_USAGE_TRACKER[user_id]["limit"] - amount)
    VISIT_USAGE_TRACKER[user_id]["limit"] = max(0, VISIT_USAGE_TRACKER[user_id]["limit"] - amount)

    bot.reply_to(message, f"➖ Removed {amount} limits. Remaining: {LIKE_USAGE_TRACKER[user_id]['limit']}")

@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!clearlimit'))
def clear_limits_all(message):
    if not is_admin(message.from_user.id):
        return

    args = message.text.split()
    if len(args) != 3 or args[1].lower() != "all" or args[2].lower() not in ["like", "visit", "both"]:
        return bot.reply_to(message,
            "❌ Usage: `!clearlimit all <like|visit|both>`",
            parse_mode="Markdown")

    mode = args[2].lower()
    cleared = 0

    all_user_ids = set()
    all_user_ids.update(LIKE_USAGE_TRACKER.keys())
    all_user_ids.update(VISIT_USAGE_TRACKER.keys())

    for uid in all_user_ids:
        uid = int(uid)
        if mode in ["like", "both"] and uid in LIKE_USAGE_TRACKER:
            LIKE_USAGE_TRACKER[uid]["limit"] = 0
            cleared += 1
        if mode in ["visit", "both"] and uid in VISIT_USAGE_TRACKER:
            VISIT_USAGE_TRACKER[uid]["limit"] = 0

    bot.reply_to(message, f"🧹 Cleared `{mode}` limits from {cleared} users.", parse_mode="Markdown")
# ====== GROUP LIST MENU (with inline buttons) ======
@bot.message_handler(func=lambda m: m.text and m.text.lower() == '!groups')
def group_list_menu(message):
    if message.from_user.id not in ADMINS:
        return
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("✅ Allowed Groups", callback_data="show_allowed_groups"),
        types.InlineKeyboardButton("🚫 Banned Groups", callback_data="show_banned_groups")
    )
    bot.reply_to(message, "📋 Select a group list to view:", reply_markup=markup)

# ====== HANDLE INLINE BUTTON CALLBACK ======
@bot.callback_query_handler(func=lambda call: call.data in ["show_allowed_groups", "show_banned_groups"])
def handle_group_list_display(call):
    if call.from_user.id not in ADMINS:
        return
    try:
        bot.delete_message(call.message.chat.id, call.message.message_id)  # ❌ Delete the menu message
    except:
        pass  
    if call.data == "show_allowed_groups":
        text = "✅ *Allowed Groups:*\n"
        if not ALLOWED_GROUP_IDS:
            text += "No allowed groups."
        else:
            for i, gid in enumerate(ALLOWED_GROUP_IDS, 1):
                try:
                    info = bot.get_chat(gid)
                    name = info.title or "Unknown"
                except:
                    name = "Unknown"
                text += f"{i}. `{gid}` - *{name}*\n"
    elif call.data == "show_banned_groups":
        text = "🚫 *Banned Groups:*\n"
        if not BANNED_GROUP_IDS:
            text += "No banned groups."
        else:
            for i, gid in enumerate(BANNED_GROUP_IDS, 1):
                try:
                    info = bot.get_chat(gid)
                    name = info.title or "Unknown"
                except:
                    name = "Unknown"
                text += f"{i}. `{gid}` - *{name}*\n"
    bot.send_message(call.message.chat.id, text, parse_mode='Markdown')
# ========== REGION + NICKNAME ==========
def get_player_info(uid):
    url = "https://shop2game.com/api/auth/player_id_login"
    headers = {
        "Accept": "application/json",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9,en;q=0.8",
        "Content-Type": "application/json",
        "Origin": "https://shop2game.com",
        "Referer": "https://shop2game.com/app",
        "sec-ch-ua": '"Google Chrome";v="111", "Not(A:Brand";v="8", "Chromium";v="111"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "Windows",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36",
        "x-datadome-clientid": "10BIK2pOeN3Cw42~iX48rEAd2OmRt6MZDJQsEeK5uMirIKyTLO2bV5Ku6~7pJl_3QOmDkJoSzDcAdCAC8J5WRG_fpqrU7crOEq0~_5oqbgJIuVFWkbuUPD~lUpzSweEa",
    }
    payload = {
        "app_id": 100067,
        "login_id": f"{uid}",
        "app_server_id": 0,
    }
    try:
        response = requests.post(url, headers=headers, json=payload)
        if response.status_code == 200:
            data = response.json()
            nickname = data.get("nickname")
            region = data.get("region")
            if not nickname and not region:
                return {"err": "❌ UID not found. Please check the UID."}
            else:
                return {"uid": f"{uid}", "name": f"{nickname}", "server": f"{region}"}
        else:
            return {"err": "❌ UID not found. Please check the UID."}
    except Exception as e:
        return {"err": f"{e}"}

def format_duration(timestamp, ago=True):
    now = datetime.utcnow()
    past = datetime.utcfromtimestamp(int(timestamp))
    diff = now - past
    days = diff.days
    seconds = diff.seconds
    years = days // 365
    months = (days % 365) // 30
    days = (days % 365) % 30
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    parts = []
    if years > 0:
        parts.append(f"{years}y")
    if months > 0:
        parts.append(f"{months}m")
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    if seconds > 0 or not parts:
        parts.append(f"{seconds}s")
    result = " ".join(parts)
    if ago:
        return result + " ago"
    return result


@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!check'))
def check_handler(message):
    try:
        if message.chat.id not in ALLOWED_GROUP_IDS:
            send_temp_message(message.chat.id, "🚫 This group is not allowed to use this bot.")
            return
        args = message.text.split()
        if len(args) != 2 or not args[1].isdigit():
            send_temp_message(message.chat.id, "❌ Use `!check <uid>`", "Markdown")
            return
        user_id = message.from_user.id
        chat_id = message.chat.id
        uid = args[1]
        start_time = time.time()
        m = bot.reply_to(message, f"⚙️ Checking Server for uid `{uid}`...")
        dtx = get_player_info(uid)
        name = dtx.get("name","N/A")
        region = dtx.get("server", "N/A")
        uidx = dtx.get("uid", "N/A")
        info_url = f"https://aditya-info-v12op.onrender.com/player-info?uid={uidx}&region={region}"
        res = requests.get(info_url)
        res.raise_for_status()
        data = res.json()
        info = data.get("player_info", {})
        b = info.get("basicInfo", {})
        timestamp_login = b.get('lastLoginAt', 'N/A')
        login_ago = format_duration(timestamp_login, ago=True)
        banner_url = f"https://aditya-banner-v12op.onrender.com/banner-image?uid={uidx}&region={region}"
        duration = round(time.time() - start_time, 2)
        caption_text = (
            f"```SUCCESS✅\n"
            f"👤 Name: {name}\n"
            f"🆔 UID: {uidx}\n"
            f"🌍 Region: {region}\n"
            f"🎮 Level: {b.get('level', 'N/A')}\n"
            f"⏳ ACTIVE: {login_ago}\n"
            f"🕐 Duration: {duration}s```\n"
        )
        threading.Timer(6, lambda: bot.delete_message(chat_id, m.message_id)).start()
        bot.send_photo(
            chat_id=message.chat.id,
            photo=banner_url,
            caption=caption_text,
            parse_mode="Markdown",
            reply_to_message_id=message.message_id
        )
    except Exception as e:
        logger.error(f"!check error: {e}")
        bot.send_message(ADMIN_ID, f"❌ Check API Error: {e}")
        send_temp_message(message.chat.id, "⚠️ Error processing check Uid.") 

# ========== IMAGE DOWNLOADER ==========
def download_image(url):
    try:
        r = requests.get(url, timeout=10)
        r.raise_for_status()
        return BytesIO(r.content)
    except Exception as e:
        logger.warning(f"Image download failed: {e}")
        return None
def to_unicode_bold(text):
    bold_map = {
        **{chr(i): chr(0x1D400 + i - 0x41) for i in range(0x41, 0x5A + 1)},   # A-Z
        **{chr(i): chr(0x1D41A + i - 0x61) for i in range(0x61, 0x7A + 1)},   # a-z
        **{chr(i): chr(0x1D7CE + i - 0x30) for i in range(0x30, 0x39 + 1)}    # 0-9
    }
    return ''.join(bold_map.get(c, c) for c in text)
# ========== INFO HANDLER ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!info'))
def handle_info(message):
    try:
        parts = message.text.strip().split()
        if len(parts) != 3:
            bot.reply_to(message, "❌ Usage:\ninfo `<uid>` `bd`\nExample: `info 1854028907 bd`", parse_mode="Markdown")
            return
        uid, region = parts[1], parts[2].lower()
        if not uid.isdigit():
            bot.reply_to(message, "❌ Please Use a valid UID.", parse_mode="Markdown")
            return
        info_url = f"https://aditya-info-v12op.onrender.com/player-info?uid={uid}&region={region}"
        banner_url = f"https://aditya-banner-v12op.onrender.com/banner-image?uid={uid}&region={region}"
        outfit_url = f"https://aditya-outfit-v12op.onrender.com/outfit-image?uid={uid}&region={region}"

        res = requests.get(info_url, timeout=10)
        res.raise_for_status()
        data = res.json()

        info = data.get("player_info", {})
        b = info.get("basicInfo", {})
        p = info.get("petInfo", {})
        pr = info.get("profileInfo", {})
        g = info.get("clanBasicInfo", {})
        l = info.get("captainBasicInfo", {})
        s = info.get("socialInfo", {})
        cr_maps = data.get("workshop_maps", [])

        maps_text = ""
        for i, cr in enumerate(cr_maps, start=1):
            maps_text += f"""📍 {to_unicode_bold("Map No")}: {i}
    ├─ {to_unicode_bold("Map Code")}: {cr.get('Code', 'N/A')}
    ├─ {to_unicode_bold("Description")}: {cr.get('Description', 'N/A')}
    └─ {to_unicode_bold("Mode Name")}: {cr.get('Name', 'N/A')}\n"""

        info_text = f"""```{to_unicode_bold("ACCOUNT INFO")}:
┌ 👤 {to_unicode_bold("ACCOUNT BASIC INFO")}
├─ {to_unicode_bold("Total Diamonds Topped Up & Claimed")}: {data.get('diamondCostRes', {}).get('diamondCost', 'N/A')}
├─ {to_unicode_bold("Prime Level")}: {b.get('primeLevel', {}).get('level', 'N/A')}
├─ {to_unicode_bold("Name")}: {b.get('nickname', 'N/A')}
├─ {to_unicode_bold("UID")}: {b.get('accountId', 'N/A')}
├─ {to_unicode_bold("Level")}: {b.get('level', 'N/A')} (Exp: {b.get('exp', 'N/A')})
├─ {to_unicode_bold("Region")}: {b.get('region', 'N/A')}
├─ {to_unicode_bold("Likes")}: {b.get('liked', 'N/A')}
├─ {to_unicode_bold("Honor Score")}: {data.get('creditScoreInfo', {}).get('creditScore', 'N/A')}
├─ {to_unicode_bold("Celebrity Status")}: {b.get('celebrityStatus', 'N/A')}
├─ {to_unicode_bold("Evo Access Badge")}: {"active" if pr.get('isSelectedAwaken') else "inactive"}
├─ {to_unicode_bold("Title ID")}: {b.get('title', 'N/A')}
└─ {to_unicode_bold("Signature")}: {s.get('signature', 'N/A')}

{to_unicode_bold("ACCOUNT ACTIVITY")}:
┌ 🎮 {to_unicode_bold("ACCOUNT ACTIVITY")}
├─ {to_unicode_bold("Most Recent OB")}: {b.get('releaseVersion', 'N/A')}
├─ {to_unicode_bold("Fire Pass")}: {"Premium" if b.get('hasElitePass') else "Free"}
├─ {to_unicode_bold("Current BP Badges")}: {b.get('badgeCnt', 'N/A')}
├─ {to_unicode_bold("BR Rank")}: {b.get('rankingPoints', 'N/A')}
├─ {to_unicode_bold("CS Rank")}: {b.get('csRankingPoints', 'N/A')}
├─ {to_unicode_bold("Created At")}: {format_ts(b.get('createAt', 'N/A'))}
└─ {to_unicode_bold("Last Login")}: {format_ts(b.get('lastLoginAt', 'N/A'))}

{to_unicode_bold("ACCOUNT OVERVIEW")}:
┌ 👕 {to_unicode_bold("ACCOUNT OVERVIEW")}
├─ {to_unicode_bold("Avatar ID")}: {pr.get('avatarId', 'N/A')}
├─ {to_unicode_bold("Banner ID")}: {b.get('bannerId', 'N/A')}
├─ {to_unicode_bold("Pin ID")}: {b.get('badgeId', 'N/A')}
├─ {to_unicode_bold("Equipped Skills")}: {pr.get('equipedSkills', [])}
├─ {to_unicode_bold("Equipped Gun ID")}: {b.get('weaponSkinShows', [])[0] if b.get('weaponSkinShows') else 'N/A'}
├─ {to_unicode_bold("Equipped Animation ID")}: {b.get('weaponSkinShows', [])[1] if len(b.get('weaponSkinShows', [])) > 1 else 'N/A'}
├─ {to_unicode_bold("Transform Animation ID")}: {b.get('weaponSkinShows', [])[2] if len(b.get('weaponSkinShows', [])) > 2 else 'N/A'}
└─ {to_unicode_bold("Outfits")}: Graphically Presented Below! 😉

{to_unicode_bold("PET DETAILS")}:
┌ 🐾 {to_unicode_bold("PET DETAILS")}
├─ {to_unicode_bold("Equipped?")}: {"Yes" if p.get('isSelected') else "No"}
├─ {to_unicode_bold("Pet Name")}: {p.get('name', 'N/A')}
├─ {to_unicode_bold("Pet Type")}: {p.get('id', 'N/A')}
├─ {to_unicode_bold("Pet Exp")}: {p.get('exp', 'N/A')}
└─ {to_unicode_bold("Pet Level")}: {p.get('level', 'N/A')}

{to_unicode_bold("GUILD INFO")}:
┌ 🛡️ {to_unicode_bold("GUILD INFO")}
├─ {to_unicode_bold("Guild Name")}: {g.get('clanName', 'N/A')}
├─ {to_unicode_bold("Guild ID")}: {g.get('clanId', 'N/A')}
├─ {to_unicode_bold("Guild Level")}: {g.get('clanLevel', 'N/A')}
├─ {to_unicode_bold("Live Members")}: {g.get('memberNum', 'N/A')}
└─ {to_unicode_bold("Leader Info")}:
    ├─ {to_unicode_bold("Leader Name")}: {l.get('nickname', 'N/A')}
    ├─ {to_unicode_bold("Leader UID")}: {l.get('accountId', 'N/A')}
    ├─ {to_unicode_bold("Leader Level")}: {l.get('level', 'N/A')} (Exp: {l.get('exp', 'N/A')})
    ├─ {to_unicode_bold("Leader Created At")}: {format_ts(l.get('createAt', 'N/A'))}
    ├─ {to_unicode_bold("Leader Last Login")}: {format_ts(l.get('lastLoginAt', 'N/A'))}
    ├─ {to_unicode_bold("Leader Title ID")}: {l.get('title', 'N/A')}
    ├─ {to_unicode_bold("Leader Current BP Badges")}: {l.get('badgeCnt', 'N/A')}
    ├─ {to_unicode_bold("Leader BR")}: {l.get('rankingPoints', 'N/A')}
    └─ {to_unicode_bold("Leader CS")}: {l.get('csRankingPoints', 'N/A')}

{to_unicode_bold("PUBLIC CRAFTLAND MAPS")}:
┌ 🗺️ {to_unicode_bold("PUBLIC CRAFTLAND MAPS")}
{maps_text}```
            🤖 {to_unicode_bold("Powered By")}\n  @UnipinZone X @AMSdeveloper
"""

        bot.send_message(
            message.chat.id,
            f"{info_text}",
            parse_mode='Markdown',
            reply_to_message_id=message.message_id
        )
        banner = download_image(banner_url)
        outfit = download_image(outfit_url)
        if banner:
            banner.name = "banner.webp"  
            bot.send_sticker(
                message.chat.id,
                sticker=banner,
                reply_to_message_id=message.message_id
            )
        if outfit:
            outfit.name = "outfit.jpg"
            bot.send_document(
                message.chat.id,
                document=outfit,
                caption="🧥 Outfit Image",
                reply_to_message_id=message.message_id
            )
    except Exception as e:
        logger.error(f"Info error: {e}")
        bot.reply_to(message, "❌ UID not found or API error.")

# ========== AGE CHECK SYSTEM ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!age'))
def age_handler(message):
    try:
        if message.chat.id not in ALLOWED_GROUP_IDS:
            send_temp_message(message.chat.id, "🚫 This group is not allowed to use this bot.")
            return
        args = message.text.split()
        if len(args) != 2 or not args[1].isdigit():
            send_temp_message(message.chat.id, "❌ Use `!age <uid>`", "Markdown")
            return
        user_id = message.from_user.id
        chat_id = message.chat.id
        uid = args[1]
        start_time = time.time()
        m = bot.reply_to(message, f"⚙️ Checking Age for uid `{uid}`...")
        dtx = get_player_info(uid)
        name = dtx.get("name")
        region = dtx.get("server")
        res = requests.get(f"https://aditya-info-v12op.onrender.com/player-info?uid={uid}&region={region.lower()}").json()
        info = res.get("player_info", {})
        b = info.get("basicInfo", {})
        timestamp_login = b.get('lastLoginAt', 'N/A')
        timestamp_age = b.get('createAt', 'N/A')
        login_ago = format_duration(timestamp_login, ago=True)
        account_age = format_duration(timestamp_age, ago=False)
        duration = round(time.time() - start_time, 2)
        send_text = (
            f"👤 NAME: {name}\n"
            f" 🌍 REGION: {region}\n"
            f" 🎮 ACTIVE: {login_ago}\n"
            f" 📅 ACCOUNT AGE: {account_age}\n"
            f" 🕒 TIME TAKEN: {duration}s\n"
        )
        threading.Timer(4, lambda: bot.delete_message(chat_id, m.message_id)).start()
        bot.send_message(
            message.chat.id,
            f"```SUCCESS✅ {send_text}```{WATERMARK}",
            parse_mode='Markdown',
            reply_to_message_id=message.message_id
        )
    except Exception as e:
        logger.error(f"!age error: {e}")
        bot.send_message(ADMIN_ID, f"❌ Age API Error: {e}")
        send_temp_message(message.chat.id, "⚠️ Error processing Account age check.") 
        
# ========== BAN CHECK SYSTEM ==========
def check_ban(uid):
    url = f"https://ff.garena.com/api/antihack/check_banned?lang=en&uid={uid}"
    headers = {
        "Host": "ff.garena.com",
        "Connection": "keep-alive",
        "sec-ch-ua-platform": "\"Android\"",
        "X-Requested-With": "B6FksShzIgjfrYImLpTsadjS86sddhFH",
        "User-Agent": "Mozilla/5.0 (Linux; Android 15; 23129RAA4G Build/AQ3A.240829.003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.7151.89 Mobile Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "sec-ch-ua": "\"Android WebView\";v=\"137\", \"Chromium\";v=\"137\", \"Not/A)Brand\";v=\"24\"",
        "sec-ch-ua-mobile": "?1",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": "https://ff.garena.com/en/support/",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8"
    }
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        if data.get('data', {}).get('is_banned', None) == 1:
            return "ban"
        if data.get('data', {}).get('is_banned', None) == 0:
            return "not_ban"
        else:
            return "invalid"
    except Exception as e:
        bot.send_message(ADMIN_ID, f"❌ Ban Main API Error: {e}")
        return {"error": f"{e}"}
# ========== BAN HANDLER ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!alive'))
def like_handler(message):
    try:
        if message.chat.id not in ALLOWED_GROUP_IDS:
            send_temp_message(message.chat.id, "🚫 This group is not allowed to use this bot.")
            return
        args = message.text.split()
        if len(args) != 2 or not args[1].isdigit():
            send_temp_message(message.chat.id, "❌ Use `!alive <uid>`", "Markdown")
            return
        user_id = message.from_user.id
        chat_id = message.chat.id
        uid = args[1]
        start_time = time.time()
        m = bot.reply_to(message, f"⚙️ Checking Ban info for uid `{uid}`...")
        ban_check = check_ban(uid)
        dtx = get_player_info(uid)
        if ban_check == "ban":
            ban_text = "Banned"
            name = dtx.get("name")
            region = dtx.get("server")
            uidx = dtx.get("uid")
            gif_url = "https://data.textstudio.com/output/sample/animated/7/8/6/4/ban-32-14687.gif"
        elif ban_check == "not_ban":
            ban_text = "Active ✅(Not Banned)"
            name = dtx.get("name")
            region = dtx.get("server")
            uidx = dtx.get("uid")
            gif_url = "https://freight.cargo.site/w/4800/q/75/i/6a7f57c14e86a7a9f9b095a5e82e4af54fb60ad4a27b9a3105891f90c7db5d16/ACTIVE_LOGO-01.gif"
        elif ban_check == "invalid":
            bot.edit_message_text("🚫 Invalid Uid. This uid is not registered in Garena Database !!", chat_id, m.message_id)
            threading.Timer(7, lambda: bot.delete_message(chat_id, m.message_id)).start()
            return
        else:
            error = ban_check.get("error")
            bot.send_message(ADMIN_ID, f"❌ Ban Check Error: {error}")
            bot.edit_message_text(f"🚫 Error : {error}", chat_id, m.message_id)
            threading.Timer(7, lambda: bot.delete_message(chat_id, m.message_id)).start()
            return
        duration = round(time.time() - start_time, 2)
        send_text = (
            f"```SUCCESS✅\n"
            f"👤 Name: {name}\n"
            f"🆔 UID: {uidx}\n"
            f"🌍 Region: {region}\n"
            f"🎮 Status: {ban_text}\n"
            f"🕐 Duration: {duration}s```\n"
        )
        threading.Timer(4, lambda: bot.delete_message(chat_id, m.message_id)).start()
        bot.send_animation(
            chat_id=message.chat.id,
            animation=gif_url,
            caption=send_text,
            parse_mode='Markdown',
            reply_to_message_id=message.message_id
          )
    except Exception as e:
        logger.error(f"!alive error: {e}")
        bot.send_message(ADMIN_ID, f"❌ Alive API Error: {e}")
        send_temp_message(message.chat.id, "⚠️ Error processing ban check.") 

# ================== WEATHER FUNCTION ==================
def get_weather_emoji(condition):
    condition = condition.lower()
    if "sun" in condition or "clear" in condition:
        return "☀️"
    elif "cloud" in condition:
        return "☁️"
    elif "rain" in condition:
        return "🌧️"
    elif "thunder" in condition:
        return "⛈️"
    elif "fog" in condition or "mist" in condition:
        return "🌫️"
    elif "snow" in condition:
        return "❄️"
    else:
        return "🌈"

def c_to_f(celsius):
    return round((celsius * 9/5) + 32, 2)

code_map = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Rime fog", 51: "Light drizzle", 53: "Moderate drizzle",
    55: "Dense drizzle", 61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    66: "Freezing rain", 67: "Heavy freezing rain", 71: "Slight snow",
    73: "Moderate snow", 75: "Heavy snow", 80: "Rain showers", 81: "Mod. showers",
    82: "Violent rain showers", 95: "Thunderstorm", 96: "Thunder w/ hail", 99: "Heavy storm"
}

# ================== WEATHER ==================

def get_weather(city_name, unit="C"):
    try:
        geo = Nominatim(user_agent="weather-bot")
        location = geo.geocode(city_name)
        if not location:
            return None, f"❌ Couldn't find location: {city_name}"

        lat, lon = location.latitude, location.longitude

        api_url = (
            f"https://api.open-meteo.com/v1/forecast?"
            f"latitude={lat}&longitude={lon}&current=temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m&timezone=auto"
        )
        res = requests.get(api_url).json()
        current = res.get("current", {})

        temp_c = current.get("temperature_2m")
        wind = current.get("wind_speed_10m")
        humidity = current.get("relative_humidity_2m")
        weather_code = current.get("weather_code")
        condition = code_map.get(weather_code, "Unknown")
        emoji = get_weather_emoji(condition)
        time_now = datetime.now().strftime('%I:%M %p')

        if unit == "F":
            temp = c_to_f(temp_c)
            temp_unit = "°F"
        else:
            temp = temp_c
            temp_unit = "°C"

        msg = (
            f"{emoji} Current weather in {city_name.title()}:\n"
            f"🌡️ Temperature: {temp}{temp_unit}\n"
            f"💧 Humidity: {humidity}%\n"
            f"💨 Wind Speed: {wind} km/h\n"
            f"🌤️ Condition: {condition}\n"
            f"🕒 Time: {time_now}"
        )
        return msg, None
    except Exception as e:
        bot.send_message(ADMIN_ID, f"❌ Weather API Error: {e}")
        return None, f"⚠️ Error: {e}"

@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!weather'))
def weather_handler(msg):
    parts = msg.text.split(" ", 1)
    if len(parts) < 2:
        send_temp_message2(msg.chat.id, "☁️ Usage: `!weather <city>`", msg.message_id, "Markdown")
        return

    city = parts[1]
    user_id = msg.from_user.id
    user_weather_units[user_id] = "C"

    text, err = get_weather(city, "C")
    if err:
        send_temp_message2(msg.chat.id, err, msg.message_id, "Markdown")
        return

    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🌡 Switch to °F", callback_data=f"unit_F|{city}"))
    bot.reply_to(msg, f"```SUCCESS✅\n{text}```\n{WATERMARK}", parse_mode="Markdown", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith("unit_"))
def switch_unit(call):
    unit, city = call.data.split("|")
    new_unit = unit.split("_")[1]
    user_id = call.from_user.id
    user_weather_units[user_id] = new_unit

    text, err = get_weather(city, new_unit)
    if err:
        send_temp_message2(call.message.chat.id, err, call.message.message_id, "Markdown")
        return

    opposite = "C" if new_unit == "F" else "F"
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton(f"🌡 Switch to °{opposite}", callback_data=f"unit_{opposite}|{city}"))

    bot.edit_message_text(
        f"```✅ SUCCESS\n\n{text}```\n{WATERMARK}",
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        parse_mode="Markdown",
        reply_markup=markup
    )

# ================== FORECAST ==================

@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!forecast'))
def forecast_handler(msg):
    try:
        parts = msg.text.split(" ", 2)
        if len(parts) < 3:
            send_temp_message2(msg.chat.id, "📍 Usage: `!forecast <city> <days>`", msg.message_id, "Markdown")
            return

        city, days = parts[1], int(parts[2])
        if not (1 <= days <= 7):
            send_temp_message2(msg.chat.id, "⚠️ Only 1 to 7 days are supported.", msg.message_id, "Markdown")
            return

        geo = Nominatim(user_agent="forecast-bot")
        location = geo.geocode(city)
        if not location:
            send_temp_message2(msg.chat.id, f"❌ Couldn't find city: {city}", msg.message_id, "Markdown")
            return

        lat, lon = location.latitude, location.longitude
        api_url = (
            f"https://api.open-meteo.com/v1/forecast?"
            f"latitude={lat}&longitude={lon}&daily=temperature_2m_min,temperature_2m_max,weather_code&timezone=auto"
        )
        res = requests.get(api_url).json()
        forecast = res.get("daily", {})

        response = f"📅 {days}-Day Forecast for {city.title()}:\n\n"
        for i in range(days):
            date = forecast['time'][i]
            min_temp = forecast['temperature_2m_min'][i]
            max_temp = forecast['temperature_2m_max'][i]
            code = forecast['weather_code'][i]
            condition = code_map.get(code, "Unknown")
            emoji = get_weather_emoji(condition)
            response += f"📆 {date} - {emoji} {condition}\n🌡️ {min_temp}°C ~ {max_temp}°C\n\n"

        bot.reply_to(msg, f"```SUCCESS✅ {response.strip()}```{WATERMARK}", parse_mode="Markdown")
    except Exception as e:
        bot.send_message(ADMIN_ID, f"❌ Forecast API Error: {e}")
        send_temp_message2(msg.chat.id, f"❌ Error: {e}", msg.message_id, "Markdown")

# ========== DATE UTILITY ==========
from datetime import datetime, timezone

def get_today():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

# ========== LIKE API CALL ==========
def call_like_api(region, uid):
    url = f"https://free-fire-like.axmhere.xyz/like?uid={uid}&server_name={region}"
    try:
        response = requests.get(url)
        if response.status_code != 200:
            bot.send_message(ADMIN_ID, f"❌ API Error: HTTP {response.status_code}")
            return "API_ERROR"
        return response.json()
    except Exception as e:
        logger.error(f"Like API error: {e}")
        bot.send_message(ADMIN_ID, f"Like API error: {e}")
        return "API_ERROR"

# ========== TRACK LIKE USAGE ==========
def can_use_like(user_id):
    data = LIKE_USAGE_TRACKER.get(user_id, {"used": 0, "limit": 0})
    remaining = data["limit"] - data["used"]
    return (remaining > 0), remaining

def record_like_usage(user_id):
    LIKE_USAGE_TRACKER.setdefault(user_id, {"used": 0, "limit": 0})
    LIKE_USAGE_TRACKER[user_id]["used"] += 1

# ========== INVITE TRACKER IN GROUP ==========
"""@bot.message_handler(content_types=['new_chat_members'])
def handle_new_members(message):
    if message.chat.id != -1002536720855:
        return
    inviter_id = message.from_user.id
    today = get_today()
    uid = str(inviter_id)
    LIKE_USAGE_TRACKER.setdefault(today, {})
    LIKE_USAGE_TRACKER[today].setdefault(uid, {"used": 0, "invited": 0})
    added = sum(1 for user in message.new_chat_members if user.id != inviter_id)
    if added > 0:
        LIKE_USAGE_TRACKER[today][uid]["invited"] += added
        bot.send_message(
            message.chat.id,
            f"🎉 @{message.from_user.username or inviter_id} invited {added} member(s)! +{added} extra request(s) today."
        )"""

# ========== LIKE PROCESS FUNCTION ==========
def process_like(message, region, uid):
    global last_like_time_global
    user_id = message.from_user.id
    chat_id = message.chat.id

    m = bot.reply_to(message, "⚙️ Processing like request...")
    start_time = time.time()

    steps = [
        "🔄 Fetching account data... 20%",
        "❓ Validating UID and region... 40%",
        "📤 Sending like requests... 70%",
        "✨ Almost done... 90%",
    ]
    for step in steps:
        time.sleep(0.2)
        bot.edit_message_text(step, chat_id, m.message_id)

    bot.edit_message_text("🔁 Retrying with refreshed tokens, please wait...", chat_id, m.message_id)
    response = call_like_api(region, uid)
    duration = round(time.time() - start_time, 2)

    if response == "API_ERROR":
        bot.edit_message_text("🚨 API Error! Try again later.", chat_id, m.message_id)
        return

    if response.get("status") == 1:
        record_like_usage(user_id)
        LIKE_COOLDOWNS[user_id] = time.time()
        user = message.from_user
        name = escape_markdown(f"{user.first_name} {user.last_name or ''}".strip())
        result_text = (
            "```🎮Like-Completed-By_AMS-FF-TEAM✅\n"
            f"├─ Name           : {response.get('PlayerNickname', 'N/A')}\n"
            f"├─ UID            : {response.get('UID', 'N/A')}\n"
            f"├─ Likes Before   : {response.get('LikesbeforeCommand', 'N/A')}\n"
            f"├─ Likes After    : {response.get('LikesafterCommand', 'N/A')}\n"
            f"├─ Liked By Bot   : {response.get('LikesGivenByAPI', 'N/A')}\n"
            f"├─ Duration       : {duration}s\n"
            f"└─ Ordered By     : {name}\n```"
            f"Subscribe Now : \n https://youtube.com/@amsgamings?")
        bot.edit_message_text(result_text, chat_id, m.message_id, parse_mode="Markdown")
    else:
        retry_info = response.get("retry", "")
        retry_text = f"\n{retry_info}" if retry_info else ""
        bot.edit_message_text(
            f"❌ This UID already received max likes today.{retry_text}",
            chat_id,
            m.message_id,
            parse_mode="Markdown"
        )

# ========== LIKE HANDLER ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!like'))
def like_handler(message):
    try:
        if message.chat.id not in ALLOWED_GROUP_IDS:
            bot.reply_to(message, "🚫 This group is not allowed to use this bot.")
            return

        user_id = message.from_user.id

        # For non-VIPs, check their remaining limit
        if user_id not in VIP_USERS:
            allowed, remaining = can_use_like(user_id)
            if not allowed:
                bot.reply_to(message, f"❌ You have no remaining requests. Please contact admin.")
                return
            record_like_usage(user_id)

        args = message.text.split()
        if len(args) != 3 or not args[1].isdigit():
            bot.reply_to(message, "❌ Use `!like <uid> <region>`")
            return

        uid = args[1]
        region = args[2].lower()
        threading.Thread(target=process_like, args=(message, region, uid)).start()

    except Exception as e:
        logger.error(f"!like error: {e}")
        bot.send_message(ADMIN_ID, f"⚠️ Error processing like.\n{e}")
        bot.reply_to(message, "⚠️ Error processing like.")

# ========== USER COMMAND ==========
# ========== USER COMMAND ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!mylimit'))
def mylimit_handler(message):
    user_id = message.from_user.id
    if user_id in VIP_USERS:
        return bot.reply_to(message, "```\n👑 You are a VIP User!\nAll your requests are unlimited. Enjoy ⚡\n```", parse_mode="Markdown")

    like = LIKE_USAGE_TRACKER.get(user_id, {"used": 0, "limit": 0})
    visit = VISIT_USAGE_TRACKER.get(user_id, {"used": 0, "limit": 0})
    result = (
        f"```\n🔐 Your Current Limits:\n"
        f"├─ Like  : {like['used']} used/{like['limit']} total | Remain: {max(0, like['limit'] - like['used'])}\n"
        f"└─ Visit : {visit['used']} used/{visit['limit']} total | Remain: {max(0, visit['limit'] - visit['used'])}\n```"
    )
    bot.reply_to(message, result, parse_mode="Markdown")

# ========== ADMIN STATS ==========
@bot.message_handler(func=lambda m: m.reply_to_message and m.text.lower().startswith('!stats'))
def full_stats_handler(message):
    if not is_admin(message.from_user.id):
        return
    target = message.reply_to_message.from_user
    uid = target.id
    name = escape_markdown(f"{target.first_name} {target.last_name or ''}".strip())

    if uid in VIP_USERS:
        return bot.reply_to(message, f"```\n👑 {name} is a VIP User!\nAll requests are unlimited. Cool ⚡\n```", parse_mode="Markdown")

    like = LIKE_USAGE_TRACKER.get(uid, {"used": 0, "limit": 0})
    visit = VISIT_USAGE_TRACKER.get(uid, {"used": 0, "limit": 0})
    result = (
        f"```\n📊 Total Stats for: {name}\n"
        f"├─ Like Used  : {like['used']}/{like['limit']} | Remain: {max(0, like['limit'] - like['used'])}\n"
        f"└─ Visit Used : {visit['used']}/{visit['limit']} | Remain: {max(0, visit['limit'] - visit['used'])}\n```"
    )
    bot.reply_to(message, result, parse_mode="Markdown")

@bot.message_handler(func=lambda m: m.text and m.text.lower().strip() == '!stats all')
def stats_all_handler(message):
    if not is_admin(message.from_user.id):
        return
    text = "```📊All-Users-Stats:\n"
    count = 1
    shown = set()
    all_user_ids = set(map(str, list(LIKE_USAGE_TRACKER.keys()))) | set(map(str, list(VISIT_USAGE_TRACKER.keys())))
    for uid in all_user_ids:
        if uid in shown:
            continue
        shown.add(uid)
        like = LIKE_USAGE_TRACKER.get(uid, {"used": 0, "limit": 0})
        visit = VISIT_USAGE_TRACKER.get(uid, {"used": 0, "limit": 0})
        try:
            user_info = bot.get_chat(int(uid))
            name = escape_markdown(f"{user_info.first_name} {user_info.last_name or ''}".strip())
        except:
            name = f"User ({uid})"

        text += (
            f"\n{count}. 👤 {name}\n"
            f"   ├─ Like  : {like['used']}/{like['limit']} | Remain: {max(0, like['limit'] - like['used'])}\n"
            f"   └─ Visit : {visit['used']}/{visit['limit']} | Remain: {max(0, visit['limit'] - visit['used'])}\n"
        )
        count += 1

    if count == 1:
        return bot.reply_to(message, "⚠️ No user data found.")
    
    text += "```"
    bot.reply_to(message, text, parse_mode="Markdown")


@bot.message_handler(func=lambda m: m.reply_to_message and m.text.lower().startswith('!todaystats'))
def today_stats_handler(message):
    if not is_admin(message.from_user.id):
        return
    target = message.reply_to_message.from_user
    uid = target.id
    name = escape_markdown(f"{target.first_name} {target.last_name or ''}".strip())

    if uid in VIP_USERS:
        return bot.reply_to(message, f"```\n👑 {name} is a VIP User!\nToday's usage is unlimited. Cool down 😉\n```", parse_mode="Markdown")

    like = LIKE_USAGE_TRACKER.get(uid, {})
    visit = VISIT_USAGE_TRACKER.get(uid, {})
    like_used = like.get("used", 0)
    visit_used = visit.get("used", 0)
    result = (
        f"```\n📅 Today's Stats for: {name}\n"
        f"├─ Like Used   : {like_used} | Remaining: {max(0, like.get('limit', 0) - like_used)}\n"
        f"└─ Visit Used  : {visit_used} | Remaining: {max(0, visit.get('limit', 0) - visit_used)}\n```"
    )
    bot.reply_to(message, result, parse_mode="Markdown")
# ========== VISIT SYSTEM ==========
# ========== UTILITY FUNCTIONS ==========
def escape_markdown(text):
    escape_chars = r'\_*[]()~`>#+-=|{}.!'
    return ''.join(['\\' + c if c in escape_chars else c for c in text])

from datetime import datetime, timezone

def get_today_utc():
    return datetime.now(timezone.utc).strftime('%Y-%m-%d')

def format_cooldown(seconds):
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    return f"{hours}h {minutes}m {seconds}s"

def get_visit_cooldown(user_id):
    now = time.time()
    last_used = LAST_VISIT_TIME.get(user_id, 0)
    return int(max(0, 86400 - (now - last_used)))


# ========== VISIT LIMIT LOGIC ==========
def can_use_visit(user_id):
    user_id = str(user_id)
    user_data = VISIT_USAGE_TRACKER.get(user_id)
    if not user_data:
        return False, 0
    used = user_data.get("used", 0)
    limit = user_data.get("limit", 0)
    remaining = max(0, limit - used)
    return remaining > 0, remaining

def record_visit_usage(user_id):
    user_id = str(user_id)
    if user_id not in VISIT_USAGE_TRACKER:
        VISIT_USAGE_TRACKER[user_id] = {"used": 1, "limit": 0}
    else:
        VISIT_USAGE_TRACKER[user_id]["used"] += 1

def has_used_free_today(user_id):
    return FREE_VISIT_LOG.get(user_id) == get_today_utc()

def record_free_visit(user_id):
    FREE_VISIT_LOG[user_id] = get_today_utc()


# ========== VISIT API CALL ==========
def call_visit_api(region, uid):
    url = f"https://free-fire-visit.axmhere.xyz/visit?uid={uid}&server={region}"
    try:
        response = requests.get(url)
        if response.status_code != 200:
            bot.send_message(ADMIN_ID, f"❌ Visit API Error: HTTP {response.status_code}")
            return "API_ERROR"
        response.encoding = 'utf-8'
        return response.json()
    except Exception as e:
        bot.send_message(ADMIN_ID, f"❌ Request Failed:\n{e}")
        return "API_ERROR"


# ========== VISIT PROCESS ==========
def process_visit(message, region, uid):
    user_id = message.from_user.id
    chat_id = message.chat.id
    m = bot.reply_to(message, "⚙️ Processing your Profile visit request...")
    start_time = time.time()

    steps = [
        "🔄 Fetching account data... 20%",
        "✅ Validating UID and region... 40%",
        "📤 Sending Visit requests... 70%",
        "✨ Almost done... 90%",
    ]
    for step in steps:
        time.sleep(0.2)
        bot.edit_message_text(step, chat_id, m.message_id)

    bot.edit_message_text("🔁 Retrying with refreshed tokens, please wait...", chat_id, m.message_id)
    response = call_visit_api(region, uid)
    duration = round(time.time() - start_time, 2)

    if response == "API_ERROR":
        bot.edit_message_text("🚨 API Error! Try again later.", chat_id, m.message_id)
        return

    status = str(response.get("status", "0")).strip()
    success_count = int(response.get("success", 0))

    if status == "1" and success_count > 0:
        VISIT_COOLDOWNS[user_id] = time.time()
        visit_request_tracker[user_id] = True
        user = message.from_user
        name = escape_markdown(f"{user.first_name} {user.last_name or ''}".strip())
        result_text = (
            "```👀Profile-Visit-Success-By_AMS-FF-TEAM✅\n"
            f"├─ Name           : {response.get('nickname', 'N/A')}\n"
            f"├─ UID            : {response.get('uid', 'N/A')}\n"
            f"├─ Level          : {response.get('level', 'N/A')}\n"
            f"├─ Visit By Bot   : {response.get('success', 'N/A')}\n"
            f"├─ Failed         : {response.get('fail', 'N/A')}\n"
            f"├─ Duration       : {duration}s\n"
            f"└─ Ordered By     : {name}```\n"
            f"Subscribe Now : \n https://youtube.com/@amsgamings?"
        )
        bot.edit_message_text(result_text, chat_id, m.message_id, parse_mode="Markdown")
    else:
        bot.edit_message_text("❌ This UID already received max visit today.", chat_id, m.message_id, parse_mode="Markdown")


# ========== VISIT HANDLER ==========
@bot.message_handler(func=lambda m: m.text and m.text.lower().startswith('!visit'))
def visit_handler(message):
    try:
        if message.chat.id not in ALLOWED_GROUP_IDS:
            bot.reply_to(message, "🚫 This group is not allowed to use this bot.")
            return

        user_id = message.from_user.id
        args = message.text.split()
        if len(args) != 3 or not args[1].isdigit():
            bot.reply_to(message, "❌ Use `!visit <uid> <region>`")
            return

        uid = args[1]
        region = args[2].lower()
        now = time.time()

        if user_id in VIP_USERS:
            threading.Thread(target=process_visit, args=(message, region, uid)).start()
            return

        allowed, _ = can_use_visit(user_id)
        if allowed:
            record_visit_usage(user_id)
            LAST_VISIT_TIME[user_id] = now
            threading.Thread(target=process_visit, args=(message, region, uid)).start()
            return

        if not has_used_free_today(user_id):
            record_free_visit(user_id)
            LAST_VISIT_TIME[user_id] = now
            threading.Thread(target=process_visit, args=(message, region, uid)).start()
            return

        cooldown = get_visit_cooldown(user_id)
        wait_text = format_cooldown(cooldown)
        bot.reply_to(message, f"❌ You already used your free visit.\n⏳ Please wait {wait_text} before using again.")

    except Exception as e:
        bot.send_message(ADMIN_ID, f"⚠️ Error processing visit: {e}")
        bot.reply_to(message, "⚠️ Error processing visit.")

# ========== START BOT ==========
if __name__ == '__main__':
    logger.info("🤖 Bot running...")
    bot.polling(none_stop=True)